#!/bin/bash
set -e

echo "╔══════════════════════════════════════════╗"
echo "║   AI 模型服務網關 - 啟動所有服務          ║"
echo "╚══════════════════════════════════════════╝"
echo ""

if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
    echo "✓ 已載入 .env"
fi

mkdir -p .pids

cleanup() {
    echo ""
    echo "正在停止所有服務..."
    for pidfile in .pids/*.pid; do
        [ -f "$pidfile" ] || continue
        pid=$(cat "$pidfile")
        name=$(basename "$pidfile" .pid)
        kill -0 "$pid" 2>/dev/null && kill "$pid" && echo "  ✓ 已停止 $name"
        rm -f "$pidfile"
    done
    exit 0
}
trap cleanup SIGINT SIGTERM

echo "[1/5] 台語 ASR — Breeze-ASR-26 (port 8001)..."
python services/breezy_asr/main.py &
echo $! > .pids/taiwanese_asr.pid

echo "[2/5] 中文 ASR — Whisper (port 8002)..."
python services/chinese_asr/main.py &
echo $! > .pids/chinese_asr.pid

echo "[3/5] 台語 TTS — Gemini + MMS-TTS (port 8003)..."
python services/taiwanese_tts/main.py &
echo $! > .pids/taiwanese_tts.pid

echo "[4/5] 中文 TTS — BreezyVoice (port 8004)..."
python services/breezy_tts/main.py &
echo $! > .pids/chinese_tts.pid

echo ""
echo "等待微服務啟動..."
sleep 5

echo "[5/5] API 網關 (port 8000)..."
python gateway.py &
echo $! > .pids/gateway.pid

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  所有服務已啟動！                         ║"
echo "║                                          ║"
echo "║  網關入口:  http://localhost:8000         ║"
echo "║  API 文件:  http://localhost:8000/docs    ║"
echo "║                                          ║"
echo "║  台語 ASR:  :8001  (Breeze-ASR-26)       ║"
echo "║  中文 ASR:  :8002  (Whisper)              ║"
echo "║  台語 TTS:  :8003  (Gemini+MMS)          ║"
echo "║  中文 TTS:  :8004  (BreezyVoice)         ║"
echo "║                                          ║"
echo "║  按 Ctrl+C 停止所有服務                   ║"
echo "╚══════════════════════════════════════════╝"
echo ""
wait
