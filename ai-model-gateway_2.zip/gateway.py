"""
AI 模型服務統一網關 (API Gateway)
=================================
所有後端只需呼叫同一個端點 POST /api/process，
透過 service_type 欄位決定走哪個模型服務。

新增服務只需：
  1. 在 services_config.yaml 加一段設定
  2. 啟動對應的微服務
  網關會自動路由，不需改任何程式碼。
"""

import os
import yaml
import logging
import time
from typing import Optional, Dict, Any, List
from datetime import datetime

from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx

from security import (
    setup_security,
    validate_audio_file,
    sanitize_text_input,
    MAX_FILE_SIZE,
    MAX_TEXT_LENGTH,
)

# ── 日誌 ──
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("gateway")

# ── FastAPI ──
app = FastAPI(
    title="AI 模型服務網關",
    description=(
        "統一入口：後端只需帶上 `service_type` 參數 + `X-API-Key` header，"
        "網關自動路由到對應的 AI 模型微服務。"
    ),
    version="2.1.0",
)

# ── CORS 白名單（從環境變數讀取）──
allowed_origins = os.getenv("ALLOWED_ORIGINS", "").split(",")
allowed_origins = [o.strip() for o in allowed_origins if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins if allowed_origins else ["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["X-API-Key", "Authorization", "Content-Type"],
)

# ── 安全中間件（API Key 認證 + 速率限制 + 日誌）──
auth_manager, rate_limiter = setup_security(app, {
    "rate_limit": int(os.getenv("RATE_LIMIT", "60")),
    "rate_window": int(os.getenv("RATE_WINDOW", "60")),
    "enable_logging": True,
})

# ── 全域狀態 ──
CONFIG: Dict = {}


# ===================== Pydantic Models =====================

class ServiceInfo(BaseModel):
    service_type: str
    name: str
    description: str
    version: str
    enabled: bool
    endpoint: str
    input_type: str
    output_type: str
    models: List[str]
    status: str = "unknown"


class GatewayResponse(BaseModel):
    """後端拿到的統一回應格式"""
    success: bool
    service_type: str
    timestamp: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    processing_time_ms: Optional[int] = None


# ===================== Config =====================

def load_config() -> Dict:
    global CONFIG
    path = os.getenv("GATEWAY_CONFIG", "services_config.yaml")
    with open(path, "r", encoding="utf-8") as f:
        CONFIG = yaml.safe_load(f)
    count = len(CONFIG.get("services", {}))
    logger.info(f"載入設定: {count} 個服務 ({path})")
    return CONFIG


def svc(service_type: str) -> Dict:
    """取得某個服務的設定，找不到就 raise。"""
    cfg = CONFIG.get("services", {}).get(service_type)
    if cfg is None:
        raise HTTPException(
            status_code=404,
            detail=f"未知的 service_type: '{service_type}'。"
                   f"可用: {list(CONFIG.get('services', {}).keys())}"
        )
    return cfg


# ===================== Helpers =====================

async def health_probe(endpoint: str, path: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{endpoint}{path}")
            return r.status_code == 200
    except Exception:
        return False


async def forward(
    cfg: Dict,
    path: str,
    *,
    files: Optional[Dict] = None,
    data: Optional[Dict] = None,
    json_body: Optional[Dict] = None,
) -> httpx.Response:
    """將請求轉發到下游微服務。"""
    url = f"{cfg['endpoint']}{path}"
    timeout = cfg.get("timeout", 60)

    try:
        async with httpx.AsyncClient(timeout=timeout) as c:
            if files:
                return await c.post(url, files=files, data=data or {})
            elif json_body:
                return await c.post(url, json=json_body)
            else:
                return await c.get(url)
    except httpx.TimeoutException:
        raise HTTPException(504, f"下游服務逾時 ({timeout}s): {url}")
    except httpx.ConnectError:
        raise HTTPException(502, f"無法連線到下游服務: {url}")
    except Exception as e:
        raise HTTPException(502, f"轉發失敗: {e}")


def ok(service_type: str, data: dict, elapsed_ms: int) -> GatewayResponse:
    return GatewayResponse(
        success=True,
        service_type=service_type,
        timestamp=datetime.now().isoformat(),
        data=data,
        processing_time_ms=elapsed_ms,
    )


def fail(service_type: str, error: str, elapsed_ms: int = 0) -> GatewayResponse:
    return GatewayResponse(
        success=False,
        service_type=service_type,
        timestamp=datetime.now().isoformat(),
        error=error,
        processing_time_ms=elapsed_ms,
    )


# ===================== Startup =====================

@app.on_event("startup")
async def startup():
    load_config()
    logger.info("網關已啟動")


# ===================== 端點 =====================

@app.get("/")
async def root():
    return {
        "service": "AI 模型服務網關",
        "version": "2.0.0",
        "available_services": [
            k for k, v in CONFIG.get("services", {}).items() if v.get("enabled")
        ],
        "docs": "/docs",
    }


@app.get("/services", response_model=List[ServiceInfo])
async def list_services():
    """列出所有已註冊的服務及其狀態。"""
    out = []
    for key, c in CONFIG.get("services", {}).items():
        is_up = False
        if c["enabled"]:
            is_up = await health_probe(c["endpoint"], c["health_check"])

        out.append(ServiceInfo(
            service_type=key,
            name=c["name"],
            description=c["description"],
            version=c["version"],
            enabled=c["enabled"],
            endpoint=c["endpoint"],
            input_type=c["input_type"],
            output_type=c["output_type"],
            models=c["models"],
            status="healthy" if is_up else ("unhealthy" if c["enabled"] else "disabled"),
        ))
    return out


@app.get("/health")
async def health():
    """所有服務的健康檢查摘要。"""
    result = {"gateway": "healthy", "services": {}}
    for key, c in CONFIG.get("services", {}).items():
        if not c["enabled"]:
            result["services"][key] = "disabled"
        else:
            up = await health_probe(c["endpoint"], c["health_check"])
            result["services"][key] = "healthy" if up else "unhealthy"
    return result


# ─────────────────────────────────────────────
#  核心端點：統一處理入口
# ─────────────────────────────────────────────

@app.post("/api/process", response_model=GatewayResponse)
async def process(
    service_type: str = Form(
        ...,
        description="要使用的服務名稱",
        examples=["taiwanese_asr", "chinese_asr", "taiwanese_tts", "chinese_tts"],
    ),
    file: Optional[UploadFile] = File(None, description="音訊 / 圖片等檔案"),
    text_input: Optional[str] = Form(None, description="文字輸入"),
    language: Optional[str] = Form(None, description="語言參數（部分服務需要）"),
    extra_params: Optional[str] = Form(None, description="其他參數（JSON 字串）"),
):
    """
    ## 統一處理入口

    後端只需呼叫這一個端點，透過 **service_type** 決定走哪個模型。

    | service_type    | 輸入     | 說明                                  |
    |-----------------|----------|---------------------------------------|
    | taiwanese_asr   | 音訊檔案 | 台語 → 中文字（Breeze-ASR-26）          |
    | chinese_asr     | 音訊檔案 | 中文語音 → 中文文字（Whisper v3 turbo） |
    | taiwanese_tts   | 文字     | 中文 → 台羅拼音 → 台語語音              |
    | chinese_tts     | 文字     | 中文 → 台灣國語語音（BreezyVoice）      |

    ### 範例 (curl)
    ```bash
    # 台語語音識別
    curl -X POST http://localhost:8000/api/process \\
      -F "service_type=taiwanese_asr" \\
      -F "file=@taiwanese.wav"

    # 中文語音識別
    curl -X POST http://localhost:8000/api/process \\
      -F "service_type=chinese_asr" \\
      -F "file=@mandarin.wav"

    # 台語 TTS（中文文字 → 台語語音）
    curl -X POST http://localhost:8000/api/process \\
      -F "service_type=taiwanese_tts" \\
      -F "text_input=你好嗎" \\
      -F 'extra_params={"speed":1.0}'
    ```
    """
    t0 = time.time()
    cfg = svc(service_type)  # 找不到會直接 404

    # 檢查是否啟用
    if not cfg["enabled"]:
        return fail(service_type, f"服務 '{service_type}' 目前未啟用")

    input_type = cfg["input_type"]
    forward_path = cfg["forward_path"]
    file_field = cfg.get("file_field", "file")

    try:
        # ── 需要檔案的服務（audio / image）──
        if input_type in ("audio", "image"):
            if file is None:
                return fail(service_type, f"此服務需要上傳檔案（input_type={input_type}）")

            contents = await file.read()

            # 安全檢查：驗證檔案
            if input_type == "audio":
                valid, error_msg = validate_audio_file(contents, file.filename or "")
                if not valid:
                    return fail(service_type, f"檔案驗證失敗: {error_msg}")

            if len(contents) > MAX_FILE_SIZE:
                return fail(service_type, f"檔案超過大小限制 ({MAX_FILE_SIZE // (1024*1024)}MB)")

            files_dict = {
                file_field: (file.filename, contents, file.content_type)
            }

            # 額外表單欄位
            form_data = {}
            if language:
                form_data["language"] = language

            resp = await forward(cfg, forward_path, files=files_dict, data=form_data)

        # ── 純文字服務（翻譯、TTS 等）──
        elif input_type == "text":
            if not text_input:
                return fail(service_type, "此服務需要提供 text_input")

            # 安全檢查：清理輸入文字
            cleaned_text, warnings = sanitize_text_input(text_input)
            if not cleaned_text:
                return fail(service_type, "輸入文字無效")
            if warnings:
                logger.info(f"[{service_type}] 輸入警告: {warnings}")

            body = {"text": cleaned_text}
            if language:
                body["language"] = language

            # 解析額外參數（如 speed, temperature 等）
            if extra_params:
                try:
                    import json
                    extra = json.loads(extra_params)
                    if isinstance(extra, dict):
                        # 只允許白名單內的參數
                        allowed_params = {"speed", "temperature", "return_format"}
                        safe_extra = {k: v for k, v in extra.items() if k in allowed_params}
                        body.update(safe_extra)
                except (json.JSONDecodeError, TypeError):
                    logger.warning(f"無法解析 extra_params: {extra_params}")

            resp = await forward(cfg, forward_path, json_body=body)

        else:
            return fail(service_type, f"不支援的 input_type: {input_type}")

        elapsed = int((time.time() - t0) * 1000)

        if resp.status_code == 200:
            return ok(service_type, resp.json(), elapsed)
        else:
            return fail(
                service_type,
                f"下游服務回傳 HTTP {resp.status_code}: {resp.text[:300]}",
                elapsed,
            )

    except HTTPException:
        raise
    except Exception as e:
        elapsed = int((time.time() - t0) * 1000)
        logger.exception(f"[{service_type}] 處理失敗")
        return fail(service_type, str(e), elapsed)


# ─────────────────────────────────────────────
#  輔助端點
# ─────────────────────────────────────────────

@app.post("/api/reload-config")
async def reload_config():
    """熱重載服務設定（不需重啟網關）。"""
    try:
        load_config()
        return {"status": "ok", "services": list(CONFIG.get("services", {}).keys())}
    except Exception as e:
        raise HTTPException(500, f"重載失敗: {e}")


# ===================== 入口 =====================

if __name__ == "__main__":
    import uvicorn

    load_config()
    port = CONFIG.get("global", {}).get("gateway_port", 8000)
    uvicorn.run(app, host="0.0.0.0", port=port)
