#!/bin/bash
# ============================================
# AI 模型服務 - 生產環境一鍵部署腳本
# 適用於 Ubuntu 22.04 / 24.04 VPS
# ============================================

set -e

# ── 顏色 ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  AI 模型服務 - 生產環境部署                    ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 檢查是否為 root ──
if [ "$EUID" -ne 0 ]; then
    error "請用 sudo 執行此腳本: sudo bash deploy.sh"
fi

# ── 收集設定 ──
read -p "你的域名（例如 api.example.com）: " DOMAIN
read -p "你的 Email（用於 SSL 憑證）: " EMAIL
read -p "你的 Gemini API Key: " GEMINI_KEY
read -p "設定一組 API Key（後端呼叫用）: " API_KEY

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ] || [ -z "$GEMINI_KEY" ] || [ -z "$API_KEY" ]; then
    error "所有欄位都是必填的"
fi

APP_DIR="/opt/ai-gateway"
APP_USER="aigateway"

info "開始部署到 ${DOMAIN}..."
echo ""

# ============================================
# 步驟 1: 系統更新 + 安裝依賴
# ============================================
info "[1/7] 安裝系統依賴..."

apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    nginx certbot python3-certbot-nginx \
    ffmpeg libsndfile1 \
    ufw git curl > /dev/null

info "系統依賴安裝完成"

# ============================================
# 步驟 2: 建立應用使用者和目錄
# ============================================
info "[2/7] 建立應用目錄..."

# 建立專用使用者（如果不存在）
id -u $APP_USER &>/dev/null || useradd -r -m -s /bin/bash $APP_USER

# 建立目錄結構
mkdir -p $APP_DIR
mkdir -p /var/log/ai-gateway

# 複製檔案（假設當前目錄有所有檔案）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -r "$SCRIPT_DIR"/{gateway.py,security.py,services_config.yaml,requirements_gateway.txt} $APP_DIR/
cp -r "$SCRIPT_DIR"/services $APP_DIR/

# 建立 .env
cat > $APP_DIR/.env << EOF
GEMINI_API_KEY=${GEMINI_KEY}
API_KEY=${API_KEY}
ALLOWED_ORIGINS=https://${DOMAIN}
RATE_LIMIT=60
RATE_WINDOW=60
EOF

chmod 600 $APP_DIR/.env
chown -R $APP_USER:$APP_USER $APP_DIR
chown -R $APP_USER:$APP_USER /var/log/ai-gateway

info "應用目錄建立完成: $APP_DIR"

# ============================================
# 步驟 3: Python 虛擬環境 + 安裝依賴
# ============================================
info "[3/7] 安裝 Python 依賴（這可能需要幾分鐘）..."

sudo -u $APP_USER python3 -m venv $APP_DIR/venv

# 網關依賴
sudo -u $APP_USER $APP_DIR/venv/bin/pip install -q --upgrade pip
sudo -u $APP_USER $APP_DIR/venv/bin/pip install -q -r $APP_DIR/requirements_gateway.txt

# 各服務依賴
for svc_dir in $APP_DIR/services/*/; do
    if [ -f "$svc_dir/requirements.txt" ]; then
        svc_name=$(basename $svc_dir)
        info "  安裝 ${svc_name} 的依賴..."
        sudo -u $APP_USER $APP_DIR/venv/bin/pip install -q -r "$svc_dir/requirements.txt"
    fi
done

info "Python 依賴安裝完成"

# ============================================
# 步驟 4: 建立 systemd 服務
# ============================================
info "[4/7] 建立 systemd 服務..."

# ── 台語 ASR ──
cat > /etc/systemd/system/ai-taiwanese-asr.service << EOF
[Unit]
Description=Taiwanese ASR Service
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/uvicorn services.taiwanese_asr.main:app --host 127.0.0.1 --port 8001
Restart=always
RestartSec=5
StandardOutput=append:/var/log/ai-gateway/taiwanese-asr.log
StandardError=append:/var/log/ai-gateway/taiwanese-asr.log

[Install]
WantedBy=multi-user.target
EOF

# ── 中文 ASR ──
cat > /etc/systemd/system/ai-chinese-asr.service << EOF
[Unit]
Description=Chinese ASR Service
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/uvicorn services.chinese_asr.main:app --host 127.0.0.1 --port 8002
Restart=always
RestartSec=5
StandardOutput=append:/var/log/ai-gateway/chinese-asr.log
StandardError=append:/var/log/ai-gateway/chinese-asr.log

[Install]
WantedBy=multi-user.target
EOF

# ── 台語 TTS ──
cat > /etc/systemd/system/ai-taiwanese-tts.service << EOF
[Unit]
Description=Taiwanese TTS Service
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/uvicorn services.taiwanese_tts.main:app --host 127.0.0.1 --port 8003
Restart=always
RestartSec=5
StandardOutput=append:/var/log/ai-gateway/taiwanese-tts.log
StandardError=append:/var/log/ai-gateway/taiwanese-tts.log

[Install]
WantedBy=multi-user.target
EOF

# ── API 網關 ──
cat > /etc/systemd/system/ai-gateway.service << EOF
[Unit]
Description=AI Model Gateway
After=network.target ai-taiwanese-asr.service ai-chinese-asr.service ai-taiwanese-tts.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/uvicorn gateway:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5
StandardOutput=append:/var/log/ai-gateway/gateway.log
StandardError=append:/var/log/ai-gateway/gateway.log

[Install]
WantedBy=multi-user.target
EOF

# 重新載入 + 啟用
systemctl daemon-reload
systemctl enable ai-taiwanese-asr ai-chinese-asr ai-taiwanese-tts ai-gateway

info "systemd 服務建立完成"

# ============================================
# 步驟 5: 設定 Nginx 反向代理
# ============================================
info "[5/7] 設定 Nginx..."

cat > /etc/nginx/sites-available/ai-gateway << 'NGINX'
server {
    listen 80;
    server_name DOMAIN_PLACEHOLDER;

    # 檔案上傳大小限制
    client_max_body_size 50M;

    # 安全 headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # 隱藏 Nginx 版本
    server_tokens off;

    # 封鎖常見攻擊路徑
    location ~ /\.(git|env|htaccess) {
        deny all;
        return 404;
    }

    # API 端點
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 超時設定（ASR/TTS 可能需要較長時間）
        proxy_connect_timeout 10s;
        proxy_send_timeout 120s;
        proxy_read_timeout 120s;

        # 禁止緩存 API 回應
        proxy_no_cache 1;
        proxy_cache_bypass 1;
    }

    # 封鎖直接訪問微服務端口
    location ~ ^/(8001|8002|8003) {
        deny all;
    }
}
NGINX

# 替換域名
sed -i "s/DOMAIN_PLACEHOLDER/${DOMAIN}/g" /etc/nginx/sites-available/ai-gateway

# 啟用站點
ln -sf /etc/nginx/sites-available/ai-gateway /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# 測試 Nginx 設定
nginx -t || error "Nginx 設定有誤"
systemctl restart nginx

info "Nginx 設定完成"

# ============================================
# 步驟 6: 防火牆
# ============================================
info "[6/7] 設定防火牆..."

ufw --force reset > /dev/null 2>&1
ufw default deny incoming
ufw default allow outgoing

# 只開放必要端口
ufw allow ssh          # SSH
ufw allow 80/tcp       # HTTP（SSL 驗證需要）
ufw allow 443/tcp      # HTTPS

# 注意：不開放 8000-8003！只有 Nginx 能存取
ufw --force enable

info "防火牆設定完成（只開放 SSH + HTTPS）"

# ============================================
# 步驟 7: SSL 憑證（Let's Encrypt）
# ============================================
info "[7/7] 取得 SSL 憑證..."

certbot --nginx \
    -d $DOMAIN \
    --email $EMAIL \
    --agree-tos \
    --non-interactive \
    --redirect

# 自動續約
systemctl enable certbot.timer

info "SSL 憑證取得成功"

# ============================================
# 啟動所有服務
# ============================================
info "啟動所有服務..."

systemctl start ai-taiwanese-asr
systemctl start ai-chinese-asr
systemctl start ai-taiwanese-tts
sleep 5  # 等微服務啟動
systemctl start ai-gateway

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  部署完成！                                          ║"
echo "║                                                      ║"
echo "║  API 入口:  https://${DOMAIN}                        "
echo "║  API 文件:  https://${DOMAIN}/docs                   "
echo "║  健康檢查:  https://${DOMAIN}/health                 "
echo "║                                                      ║"
echo "║  API Key:   ${API_KEY}                               "
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "後端呼叫方式:"
echo ""
echo "  curl -X POST https://${DOMAIN}/api/process \\"
echo "    -H 'X-API-Key: ${API_KEY}' \\"
echo "    -F 'service_type=chinese_asr' \\"
echo "    -F 'file=@audio.wav'"
echo ""
echo "常用管理命令:"
echo "  查看狀態:   systemctl status ai-gateway"
echo "  查看日誌:   tail -f /var/log/ai-gateway/gateway.log"
echo "  重啟全部:   systemctl restart ai-gateway ai-taiwanese-asr ai-chinese-asr ai-taiwanese-tts"
echo "  停止全部:   systemctl stop ai-gateway ai-taiwanese-asr ai-chinese-asr ai-taiwanese-tts"
echo ""
