"""
安全中間件模組
==============
為 API 網關提供：
  1. API Key 認證
  2. 速率限制（per-key + 全域）
  3. 檔案上傳驗證（大小 + magic bytes）
  4. 輸入文字過濾（長度限制 + prompt injection 防護）
  5. 請求日誌與稽核
  6. CORS 白名單
  7. HTTPS 強制（生產環境）
"""

import os
import time
import hashlib
import logging
import secrets
from typing import Optional, Dict, Set
from collections import defaultdict
from datetime import datetime

from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("security")


# =====================================================
#  1. API Key 認證
# =====================================================

class APIKeyAuth:
    """
    API Key 認證管理器

    用法：
        auth = APIKeyAuth()
        auth.load_keys_from_env()       # 從環境變數載入
        # 或
        auth.add_key("my-key", "後端服務A")

    驗證：
        key_info = auth.validate("my-key")  # 成功回傳 dict，失敗回傳 None
    """

    def __init__(self):
        # key_hash → metadata
        self._keys: Dict[str, Dict] = {}
        # 不需要認證的路徑
        self.public_paths: Set[str] = {
            "/",
            "/docs",
            "/openapi.json",
            "/redoc",
            "/health",
        }

    def _hash_key(self, key: str) -> str:
        """用 SHA-256 雜湊儲存 key（不存明文）"""
        return hashlib.sha256(key.encode()).hexdigest()

    def add_key(self, key: str, name: str, permissions: list = None):
        """新增一組 API key"""
        h = self._hash_key(key)
        self._keys[h] = {
            "name": name,
            "permissions": permissions or ["*"],
            "created_at": datetime.now().isoformat(),
        }
        logger.info(f"已新增 API key: {name}")

    def generate_key(self, name: str) -> str:
        """產生一組安全的隨機 API key"""
        key = f"sk-{secrets.token_urlsafe(32)}"
        self.add_key(key, name)
        return key

    def load_keys_from_env(self):
        """
        從環境變數載入 API keys
        格式：API_KEYS=key1:name1,key2:name2
        或單一 key：API_KEY=your-key
        """
        # 單一 key
        single = os.getenv("API_KEY")
        if single:
            self.add_key(single, "default")

        # 多組 keys
        multi = os.getenv("API_KEYS", "")
        for pair in multi.split(","):
            pair = pair.strip()
            if ":" in pair:
                key, name = pair.split(":", 1)
                self.add_key(key.strip(), name.strip())
            elif pair:
                self.add_key(pair, "unnamed")

    def validate(self, key: str) -> Optional[Dict]:
        """驗證 API key，成功回傳 metadata，失敗回傳 None"""
        if not key:
            return None
        h = self._hash_key(key)
        return self._keys.get(h)

    def has_keys(self) -> bool:
        """是否有設定任何 key"""
        return len(self._keys) > 0


# =====================================================
#  2. 速率限制
# =====================================================

class RateLimiter:
    """
    簡易滑動視窗速率限制器

    用法：
        limiter = RateLimiter(max_requests=60, window_seconds=60)
        allowed, remaining = limiter.check("client-id")
    """

    def __init__(self, max_requests: int = 60, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window = window_seconds
        # client_id → list of timestamps
        self._requests: Dict[str, list] = defaultdict(list)

    def check(self, client_id: str) -> tuple[bool, int]:
        """
        檢查是否允許請求

        Returns:
            (allowed: bool, remaining: int)
        """
        now = time.time()
        cutoff = now - self.window

        # 清除過期紀錄
        timestamps = self._requests[client_id]
        self._requests[client_id] = [t for t in timestamps if t > cutoff]

        current_count = len(self._requests[client_id])

        if current_count >= self.max_requests:
            return False, 0

        self._requests[client_id].append(now)
        remaining = self.max_requests - current_count - 1
        return True, remaining

    def cleanup(self):
        """定期清理過期紀錄（記憶體管理）"""
        now = time.time()
        cutoff = now - self.window
        empty_keys = []
        for key, timestamps in self._requests.items():
            self._requests[key] = [t for t in timestamps if t > cutoff]
            if not self._requests[key]:
                empty_keys.append(key)
        for key in empty_keys:
            del self._requests[key]


# =====================================================
#  3. 檔案驗證
# =====================================================

# 常見音訊格式的 magic bytes
AUDIO_SIGNATURES = {
    b"RIFF": "wav",           # WAV
    b"\xff\xfb": "mp3",      # MP3 (MPEG)
    b"\xff\xf3": "mp3",      # MP3 (MPEG)
    b"\xff\xf2": "mp3",      # MP3 (MPEG)
    b"ID3": "mp3",           # MP3 with ID3 tag
    b"fLaC": "flac",         # FLAC
    b"OggS": "ogg",          # OGG
    b"\x00\x00\x00": "m4a",  # M4A/MP4 (partial)
}

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_TEXT_LENGTH = 5000             # 最大文字輸入長度


def validate_audio_file(content: bytes, filename: str = "") -> tuple[bool, str]:
    """
    驗證音訊檔案

    Returns:
        (valid: bool, error_message: str)
    """
    # 檢查大小
    if len(content) == 0:
        return False, "檔案為空"

    if len(content) > MAX_FILE_SIZE:
        size_mb = len(content) / (1024 * 1024)
        return False, f"檔案過大: {size_mb:.1f}MB（上限 {MAX_FILE_SIZE // (1024*1024)}MB）"

    # 檢查 magic bytes
    is_valid_audio = False
    for signature, fmt in AUDIO_SIGNATURES.items():
        if content[:len(signature)] == signature:
            is_valid_audio = True
            break

    # 也檢查副檔名作為輔助判斷
    valid_extensions = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".opus", ".webm"}
    if filename:
        ext = os.path.splitext(filename)[1].lower()
        if ext in valid_extensions:
            is_valid_audio = True

    if not is_valid_audio:
        return False, "不支援的檔案格式（支援: wav, mp3, flac, ogg, m4a）"

    return True, ""


# =====================================================
#  4. 輸入過濾
# =====================================================

# 常見 prompt injection 模式
INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore all instructions",
    "disregard your instructions",
    "forget your instructions",
    "你是一個",
    "假裝你是",
    "pretend you are",
    "act as if",
    "system prompt",
    "reveal your prompt",
]


def sanitize_text_input(text: str) -> tuple[str, list]:
    """
    清理文字輸入

    Returns:
        (cleaned_text: str, warnings: list)
    """
    warnings = []

    if not text or not text.strip():
        return "", ["輸入為空"]

    # 長度限制
    if len(text) > MAX_TEXT_LENGTH:
        text = text[:MAX_TEXT_LENGTH]
        warnings.append(f"文字已截斷至 {MAX_TEXT_LENGTH} 字元")

    # 移除控制字元（保留換行和空格）
    cleaned = ""
    for ch in text:
        if ch in ("\n", "\r", "\t") or (ord(ch) >= 32):
            cleaned += ch
    text = cleaned

    # 檢查 prompt injection（只記錄警告，不阻擋）
    text_lower = text.lower()
    for pattern in INJECTION_PATTERNS:
        if pattern in text_lower:
            warnings.append(f"偵測到可疑輸入模式: {pattern[:20]}...")
            logger.warning(f"Prompt injection 嘗試: {text[:100]}")
            break

    return text.strip(), warnings


# =====================================================
#  5. 安全中間件（整合以上所有功能）
# =====================================================

class SecurityMiddleware(BaseHTTPMiddleware):
    """
    FastAPI 安全中間件

    用法：
        app.add_middleware(SecurityMiddleware,
            api_key_auth=auth,
            rate_limiter=limiter,
            allowed_origins=["https://yourdomain.com"])
    """

    def __init__(
        self,
        app,
        api_key_auth: APIKeyAuth = None,
        rate_limiter: RateLimiter = None,
        allowed_origins: list = None,
        enable_logging: bool = True,
    ):
        super().__init__(app)
        self.auth = api_key_auth or APIKeyAuth()
        self.limiter = rate_limiter or RateLimiter()
        self.allowed_origins = set(allowed_origins or [])
        self.enable_logging = enable_logging

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        client_ip = request.client.host if request.client else "unknown"

        # ── 1. API Key 認證 ──
        if self.auth.has_keys() and request.url.path not in self.auth.public_paths:
            api_key = (
                request.headers.get("X-API-Key")
                or request.headers.get("Authorization", "").removeprefix("Bearer ")
            )

            key_info = self.auth.validate(api_key)
            if key_info is None:
                if self.enable_logging:
                    logger.warning(f"認證失敗 | IP: {client_ip} | Path: {request.url.path}")
                return JSONResponse(
                    status_code=401,
                    content={
                        "success": False,
                        "error": "無效的 API Key。請在 X-API-Key header 提供有效的金鑰。"
                    }
                )

            # 把 key info 存到 request state 供後續使用
            request.state.api_key_name = key_info["name"]

        # ── 2. 速率限制 ──
        # 優先用 API key name，否則用 IP
        rate_key = getattr(request.state, "api_key_name", client_ip)
        allowed, remaining = self.limiter.check(rate_key)

        if not allowed:
            if self.enable_logging:
                logger.warning(f"速率限制 | Key: {rate_key} | IP: {client_ip}")
            return JSONResponse(
                status_code=429,
                content={
                    "success": False,
                    "error": "請求過於頻繁，請稍後再試。"
                },
                headers={
                    "Retry-After": str(self.limiter.window),
                    "X-RateLimit-Remaining": "0",
                }
            )

        # ── 3. 處理請求 ──
        response = await call_next(request)

        # ── 4. 加上安全 headers ──
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Cache-Control"] = "no-store"

        # ── 5. 請求日誌 ──
        if self.enable_logging:
            elapsed = int((time.time() - start_time) * 1000)
            key_name = getattr(request.state, "api_key_name", "anonymous")
            logger.info(
                f"{request.method} {request.url.path} | "
                f"{response.status_code} | "
                f"{elapsed}ms | "
                f"Key: {key_name} | "
                f"IP: {client_ip}"
            )

        return response


# =====================================================
#  6. 工具函式
# =====================================================

def setup_security(app, config: dict = None):
    """
    一鍵設定所有安全功能

    用法：
        from security import setup_security
        setup_security(app, {
            "allowed_origins": ["https://yourdomain.com"],
            "rate_limit": 60,           # 每分鐘最大請求數
            "rate_window": 60,          # 速率限制視窗（秒）
            "enable_logging": True,
        })
    """
    config = config or {}

    # 建立認證管理器
    auth = APIKeyAuth()
    auth.load_keys_from_env()

    # 如果沒有設定任何 key，自動產生一組並印出
    if not auth.has_keys():
        generated = auth.generate_key("auto-generated")
        logger.warning("=" * 60)
        logger.warning("  未偵測到 API_KEY 環境變數")
        logger.warning(f"  已自動產生 API Key: {generated}")
        logger.warning("  請儲存此 key 並設定到你的後端")
        logger.warning("  設定方式: export API_KEY=<key>")
        logger.warning("=" * 60)

    # 建立速率限制器
    limiter = RateLimiter(
        max_requests=config.get("rate_limit", 60),
        window_seconds=config.get("rate_window", 60),
    )

    # 取得允許的來源
    origins = config.get("allowed_origins", [])
    env_origins = os.getenv("ALLOWED_ORIGINS", "")
    if env_origins:
        origins.extend(env_origins.split(","))

    # 安裝中間件
    app.add_middleware(
        SecurityMiddleware,
        api_key_auth=auth,
        rate_limiter=limiter,
        allowed_origins=origins,
        enable_logging=config.get("enable_logging", True),
    )

    return auth, limiter
