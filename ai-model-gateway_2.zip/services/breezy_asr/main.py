"""
台語語音識別服務 (Breeze-ASR-26)
================================
台語語音 → 中文字（直接輸出，不需額外翻譯）

模型: MediaTek-Research/Breeze-ASR-26
基於 Whisper 微調，專為台語語音優化
端口: 8001
"""

import os
import io
import tempfile
import logging
from typing import Optional

import torch
import librosa
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from transformers import WhisperProcessor, WhisperForConditionalGeneration, AutomaticSpeechRecognitionPipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="台語語音識別服務 (Breeze-ASR-26)",
    description="台語語音 → 中文字",
    version="2.0.0",
)

MODEL_ID = "MediaTek-Research/Breeze-ASR-26"
asr_pipeline = None


class TranscriptionResponse(BaseModel):
    text: str
    audio_duration: float
    success: bool
    error: Optional[str] = None


def initialize_model():
    global asr_pipeline

    try:
        logger.info(f"正在載入模型: {MODEL_ID} ...")

        device = "cuda:0" if torch.cuda.is_available() else "cpu"
        torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        logger.info(f"裝置: {device}, 精度: {torch_dtype}")

        processor = WhisperProcessor.from_pretrained(MODEL_ID)

        model = WhisperForConditionalGeneration.from_pretrained(
            MODEL_ID,
            torch_dtype=torch_dtype,
            low_cpu_mem_usage=True,
        )
        model.to(device)

        asr_pipeline = AutomaticSpeechRecognitionPipeline(
            model=model,
            tokenizer=processor.tokenizer,
            feature_extractor=processor.feature_extractor,
            torch_dtype=torch_dtype,
            device=device,
            chunk_length_s=30,
            batch_size=16,
        )

        logger.info("模型載入成功！")

    except Exception as e:
        logger.error(f"模型載入失敗: {e}")
        raise


@app.on_event("startup")
async def startup():
    initialize_model()


@app.get("/")
async def root():
    return {
        "status": "running",
        "service": "台語語音識別 (Breeze-ASR-26)",
        "model": MODEL_ID,
        "ready": asr_pipeline is not None,
    }


@app.post("/api/transcribe", response_model=TranscriptionResponse)
async def transcribe(
    audio_file: UploadFile = File(..., description="台語音訊檔案"),
):
    """台語語音 → 中文字"""
    temp_path = None
    try:
        if asr_pipeline is None:
            raise HTTPException(503, "模型尚未載入完成")

        contents = await audio_file.read()
        if len(contents) == 0:
            raise HTTPException(400, "檔案為空")

        suffix = os.path.splitext(audio_file.filename or ".wav")[1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents)
            temp_path = tmp.name

        # 載入音訊，重取樣到 16kHz
        audio_array, sr = librosa.load(temp_path, sr=16000)
        audio_duration = len(audio_array) / sr
        logger.info(f"音訊: {audio_duration:.1f}s, 檔案: {audio_file.filename}")

        # Breeze-ASR-26 直接輸出中文字，不需指定語言
        result = asr_pipeline(
            audio_array,
            return_timestamps=False,
        )

        text = result["text"].strip()
        logger.info(f"識別結果: {text}")

        return TranscriptionResponse(
            text=text,
            audio_duration=audio_duration,
            success=True,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("識別失敗")
        return TranscriptionResponse(
            text="", audio_duration=0, success=False, error=str(e)
        )
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
