"""
台語文字轉語音服務 — Gemini + MMS-TTS-nan
中文字 → 台羅拼音(Gemini) → 台語語音(MMS-TTS)
端口: 8003
"""
import os, io, base64, logging, tempfile
from typing import Optional
import torch, numpy as np
import scipy.io.wavfile as wav
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from transformers import VitsModel, AutoTokenizer
import google.generativeai as genai

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
app = FastAPI(title="台語文字轉語音服務", version="1.0.0")

tts_model = None
tts_tokenizer = None
genai_configured = False
MODEL_ID = "facebook/mms-tts-nan"
GEMINI_MODEL = "gemini-2.0-flash"
SAMPLE_RATE = 16000

class TTSRequest(BaseModel):
    text: str
    speed: float = 1.0

class TTSResponse(BaseModel):
    success: bool
    tailo_romanization: str
    original_text: str
    audio_base64: Optional[str] = None
    audio_duration: Optional[float] = None
    sample_rate: int = SAMPLE_RATE
    error: Optional[str] = None

def initialize():
    global tts_model, tts_tokenizer, genai_configured
    logger.info(f"載入 TTS: {MODEL_ID}")
    tts_tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    tts_model = VitsModel.from_pretrained(MODEL_ID)
    if torch.cuda.is_available(): tts_model = tts_model.to("cuda")
    tts_model.eval()
    logger.info("TTS 載入成功")
    key = os.getenv("GEMINI_API_KEY")
    if key:
        genai.configure(api_key=key)
        genai_configured = True
        logger.info("Gemini API 配置成功")

def chinese_to_tailo(text: str) -> str:
    model = genai.GenerativeModel(GEMINI_MODEL)
    prompt = f"請將以下繁體中文轉換為台羅拼音（Tâi-lô），只輸出拼音：\n{text}"
    return model.generate_content(prompt).text.strip().strip("'\"")

def tailo_to_speech(text: str) -> tuple:
    inputs = tts_tokenizer(text, return_tensors="pt")
    if torch.cuda.is_available(): inputs = {k: v.to("cuda") for k, v in inputs.items()}
    with torch.no_grad(): output = tts_model(**inputs)
    wf = output.waveform[0].cpu().numpy()
    if np.max(np.abs(wf)) > 0: wf = wf / np.max(np.abs(wf)) * 0.95
    return wf, len(wf) / SAMPLE_RATE

@app.on_event("startup")
async def startup(): initialize()

@app.get("/")
async def root():
    return {"status": "running", "service": "台語TTS", "ready": tts_model is not None and genai_configured}

@app.post("/api/synthesize", response_model=TTSResponse)
async def synthesize(request: TTSRequest):
    try:
        if not tts_model: raise HTTPException(503, "TTS 未載入")
        if not genai_configured: raise HTTPException(503, "Gemini 未配置")
        if not request.text.strip(): raise HTTPException(400, "文字不可為空")
        tailo = chinese_to_tailo(request.text)
        wf, dur = tailo_to_speech(tailo)
        pcm = (wf * 32767).astype(np.int16)
        buf = io.BytesIO(); wav.write(buf, SAMPLE_RATE, pcm); buf.seek(0)
        b64 = base64.b64encode(buf.read()).decode()
        return TTSResponse(success=True, tailo_romanization=tailo, original_text=request.text, audio_base64=b64, audio_duration=dur)
    except HTTPException: raise
    except Exception as e:
        return TTSResponse(success=False, tailo_romanization="", original_text=request.text, error=str(e))

if __name__ == "__main__":
    import uvicorn; uvicorn.run(app, host="0.0.0.0", port=8003)
