"""
中文文字轉語音服務 (BreezyVoice)
================================
中文文字 → 台灣國語語音（支援語音克隆）

模型: MediaTek-Research/BreezyVoice
基於 CosyVoice，專為台灣國語優化
端口: 8004
"""

import os
import sys
import io
import base64
import logging
import tempfile
from typing import Optional

import torch
import numpy as np
import torchaudio
from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="中文文字轉語音服務 (BreezyVoice)",
    description="中文文字 → 台灣國語語音（支援語音克隆）",
    version="1.0.0",
)

# 全域變數
cosyvoice_model = None
BREEZY_REPO = os.getenv("BREEZY_REPO_PATH", "/app/BreezyVoice")
MODEL_PATH = os.getenv("BREEZY_MODEL_PATH", "MediaTek-Research/BreezyVoice")
SAMPLE_RATE = 22050


class TTSRequest(BaseModel):
    text: str
    speed: float = 1.0


class TTSResponse(BaseModel):
    success: bool
    original_text: str
    audio_base64: Optional[str] = None
    audio_duration: Optional[float] = None
    sample_rate: int = SAMPLE_RATE
    error: Optional[str] = None


def initialize_model():
    """載入 BreezyVoice 模型"""
    global cosyvoice_model, SAMPLE_RATE

    try:
        logger.info("正在載入 BreezyVoice 模型...")

        # 加入 BreezyVoice repo 到 path
        if os.path.exists(BREEZY_REPO):
            sys.path.insert(0, BREEZY_REPO)
            # BreezyVoice 的子模組也需要
            third_party = os.path.join(BREEZY_REPO, "third_party", "Matcha-TTS")
            if os.path.exists(third_party):
                sys.path.insert(0, third_party)

        from cosyvoice.cli.cosyvoice import CosyVoice

        cosyvoice_model = CosyVoice(MODEL_PATH)

        # 取得 sample rate
        if hasattr(cosyvoice_model, 'sample_rate'):
            SAMPLE_RATE = cosyvoice_model.sample_rate

        logger.info(f"BreezyVoice 載入成功！Sample rate: {SAMPLE_RATE}")

    except ImportError as e:
        logger.error(
            f"BreezyVoice 載入失敗（缺少依賴）: {e}\n"
            f"請確認已 clone BreezyVoice repo 到 {BREEZY_REPO}\n"
            f"git clone https://github.com/mtkresearch/BreezyVoice.git"
        )
        raise
    except Exception as e:
        logger.error(f"BreezyVoice 載入失敗: {e}")
        raise


def synthesize(text: str, prompt_audio: str = None, prompt_text: str = None) -> tuple:
    """
    合成語音

    Args:
        text: 要合成的中文文字
        prompt_audio: 參考音訊路徑（語音克隆用）
        prompt_text: 參考音訊的文字轉錄（語音克隆用）

    Returns:
        (waveform numpy array, sample_rate)
    """
    if cosyvoice_model is None:
        raise RuntimeError("模型未載入")

    try:
        # 如果有參考音訊 → 語音克隆模式
        if prompt_audio and os.path.exists(prompt_audio):
            logger.info(f"語音克隆模式: '{text}'")
            output_iter = cosyvoice_model.inference_zero_shot(
                tts_text=text,
                prompt_text=prompt_text or "",
                prompt_speech_16k=load_audio_16k(prompt_audio),
            )
        else:
            # 預設語音模式
            logger.info(f"預設語音模式: '{text}'")
            output_iter = cosyvoice_model.inference_sft(
                tts_text=text,
                spk_id="default",
            )

        # 收集所有音訊片段
        all_audio = []
        for chunk in output_iter:
            if "tts_speech" in chunk:
                audio = chunk["tts_speech"].numpy()
                if audio.ndim > 1:
                    audio = audio.squeeze()
                all_audio.append(audio)

        if not all_audio:
            raise RuntimeError("模型未產生音訊")

        waveform = np.concatenate(all_audio)
        duration = len(waveform) / SAMPLE_RATE
        logger.info(f"合成完成: {duration:.2f}s")

        return waveform, SAMPLE_RATE

    except Exception as e:
        logger.exception("語音合成失敗")
        raise


def load_audio_16k(path: str):
    """載入音訊並重取樣到 16kHz"""
    waveform, sr = torchaudio.load(path)
    if sr != 16000:
        resampler = torchaudio.transforms.Resample(sr, 16000)
        waveform = resampler(waveform)
    return waveform


def waveform_to_wav_bytes(waveform: np.ndarray, sr: int) -> bytes:
    """轉換為 WAV bytes"""
    import scipy.io.wavfile as wav
    pcm = (waveform * 32767).astype(np.int16)
    buf = io.BytesIO()
    wav.write(buf, sr, pcm)
    buf.seek(0)
    return buf.read()


@app.on_event("startup")
async def startup():
    initialize_model()


@app.get("/")
async def root():
    return {
        "status": "running",
        "service": "中文文字轉語音 (BreezyVoice)",
        "model": MODEL_PATH,
        "ready": cosyvoice_model is not None,
    }


@app.post("/api/synthesize", response_model=TTSResponse)
async def api_synthesize(
    text: str = Form(..., description="要合成的中文文字"),
    speed: float = Form(1.0, description="語速"),
    speaker_audio: Optional[UploadFile] = File(None, description="參考音訊（語音克隆）"),
    speaker_text: Optional[str] = Form(None, description="參考音訊的文字轉錄"),
):
    """
    中文文字 → 台灣國語語音

    可選語音克隆：上傳一段參考音訊，模型會模仿該說話者的聲音。
    """
    temp_audio = None
    try:
        if cosyvoice_model is None:
            raise HTTPException(503, "模型未載入")
        if not text.strip():
            raise HTTPException(400, "文字不可為空")

        # 處理參考音訊
        prompt_path = None
        if speaker_audio:
            contents = await speaker_audio.read()
            suffix = os.path.splitext(speaker_audio.filename or ".wav")[1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(contents)
                temp_audio = tmp.name
                prompt_path = tmp.name

        # 合成語音
        waveform, sr = synthesize(
            text=text,
            prompt_audio=prompt_path,
            prompt_text=speaker_text,
        )

        # 轉為 WAV bytes + base64
        wav_bytes = waveform_to_wav_bytes(waveform, sr)
        audio_b64 = base64.b64encode(wav_bytes).decode("utf-8")
        duration = len(waveform) / sr

        return TTSResponse(
            success=True,
            original_text=text,
            audio_base64=audio_b64,
            audio_duration=duration,
            sample_rate=sr,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("合成失敗")
        return TTSResponse(
            success=False,
            original_text=text,
            error=str(e),
        )
    finally:
        if temp_audio and os.path.exists(temp_audio):
            os.remove(temp_audio)


@app.post("/api/synthesize-stream")
async def api_synthesize_stream(
    text: str = Form(...),
    speed: float = Form(1.0),
):
    """直接回傳 WAV 音訊串流"""
    try:
        if cosyvoice_model is None:
            raise HTTPException(503, "模型未載入")

        waveform, sr = synthesize(text=text)
        wav_bytes = waveform_to_wav_bytes(waveform, sr)

        return StreamingResponse(
            io.BytesIO(wav_bytes),
            media_type="audio/wav",
            headers={"Content-Disposition": "attachment; filename=breezyvoice.wav"},
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004)
