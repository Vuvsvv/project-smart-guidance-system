"""
中文語音識別服務 — Whisper large-v3-turbo
端口: 8002
"""
import os, tempfile, logging
from typing import Optional
import torch, librosa
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
app = FastAPI(title="中文語音識別服務", version="1.0.0")

MODEL_ID = "openai/whisper-large-v3-turbo"
asr_pipeline = None

class TranscriptionResponse(BaseModel):
    text: str
    language: str
    audio_duration: float
    success: bool
    error: Optional[str] = None

def initialize_model():
    global asr_pipeline
    logger.info(f"正在載入模型: {MODEL_ID} ...")
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    logger.info(f"使用裝置: {device}, 精度: {torch_dtype}")
    model = AutoModelForSpeechSeq2Seq.from_pretrained(MODEL_ID, torch_dtype=torch_dtype, low_cpu_mem_usage=True, use_safetensors=True)
    model.to(device)
    processor = AutoProcessor.from_pretrained(MODEL_ID)
    asr_pipeline = pipeline("automatic-speech-recognition", model=model, tokenizer=processor.tokenizer, feature_extractor=processor.feature_extractor, torch_dtype=torch_dtype, device=device, chunk_length_s=30, batch_size=16)
    logger.info("模型載入成功！")

@app.on_event("startup")
async def startup():
    initialize_model()

@app.get("/")
async def root():
    return {"status": "running", "service": "中文語音識別服務", "model": MODEL_ID, "ready": asr_pipeline is not None}

@app.post("/api/transcribe", response_model=TranscriptionResponse)
async def transcribe(audio_file: UploadFile = File(...), language: str = "zh"):
    temp = None
    try:
        if asr_pipeline is None: raise HTTPException(503, "模型尚未載入完成")
        contents = await audio_file.read()
        if not contents: raise HTTPException(400, "檔案為空")
        suffix = os.path.splitext(audio_file.filename or ".wav")[1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents); temp = tmp.name
        audio, sr = librosa.load(temp, sr=16000)
        dur = len(audio) / sr
        result = asr_pipeline(audio, generate_kwargs={"language": language, "task": "transcribe"}, return_timestamps=False)
        return TranscriptionResponse(text=result["text"].strip(), language=language, audio_duration=dur, success=True)
    except HTTPException: raise
    except Exception as e:
        return TranscriptionResponse(text="", language=language, audio_duration=0, success=False, error=str(e))
    finally:
        if temp and os.path.exists(temp): os.remove(temp)

if __name__ == "__main__":
    import uvicorn; uvicorn.run(app, host="0.0.0.0", port=8002)
