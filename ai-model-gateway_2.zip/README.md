# AI 模型服務網關

統一管理多個 AI 模型的 API 網關。後端只需呼叫一個端點，透過 `service_type` 參數決定使用哪個模型。

## 架構

```
                           ┌──────────────────────┐
                           │  API Gateway (:8000)  │
      後端 ── POST ──────▶ │  依 service_type 路由  │
      service_type=xxx     └──┬──────┬──────┬──────┬──┘
                              │      │      │      │
           ┌──────────────────┘      │      │      └──────────────────┐
           ▼                         ▼      ▼                         ▼
 ┌──────────────────┐  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────────┐
 │ 台語 ASR (:8001) │  │ 中文 ASR (:8002)│  │ 台語 TTS (:8003)│  │ 中文 TTS (:8004) │
 │ Breeze-ASR-26    │  │ Whisper-v3-turbo│  │ Gemini+MMS-TTS  │  │ BreezyVoice      │
 │                  │  │                 │  │                 │  │                  │
 │ 台語語音→中文字  │  │ 中文語音→中文字 │  │ 中文字→台語語音 │  │ 中文字→國語語音  │
 └──────────────────┘  └─────────────────┘  └─────────────────┘  └──────────────────┘
```

## 服務總覽

| service_type | 輸入 | 輸出 | 模型 |
|---|---|---|---|
| `taiwanese_asr` | 台語音訊 | 中文字 | MediaTek-Research/Breeze-ASR-26 |
| `chinese_asr` | 中文音訊 | 中文字 | openai/whisper-large-v3-turbo |
| `taiwanese_tts` | 中文字 | 台語語音 + 台羅拼音 | Gemini 3 Flash + facebook/mms-tts-nan |
| `chinese_tts` | 中文字 | 台灣國語語音 | MediaTek-Research/BreezyVoice |

## 快速開始

```bash
# 1. 安裝所有依賴
pip install -r requirements_gateway.txt
pip install -r services/breezy_asr/requirements.txt
pip install -r services/chinese_asr/requirements.txt
pip install -r services/taiwanese_tts/requirements.txt
pip install -r services/breezy_tts/requirements.txt

# 2. BreezyVoice 需要額外 clone repo
git clone https://github.com/mtkresearch/BreezyVoice.git
export BREEZY_REPO_PATH=$(pwd)/BreezyVoice

# 3. 設定環境變數
export GEMINI_API_KEY="your_gemini_key"
export API_KEY="your_gateway_key"

# 4. 一鍵啟動
./start_all.sh

# 或用 Docker（自動處理 BreezyVoice clone）
docker-compose up -d
```

API 文件：http://localhost:8000/docs

## 後端整合

後端只需要這些程式碼，同一個端點切換四種服務：

```python
import requests, json, base64

GATEWAY = "http://localhost:8000"
HEADERS = {"X-API-Key": "your_gateway_key"}

# ── 台語語音 → 中文字（Breeze-ASR-26）──
with open("taiwanese.wav", "rb") as f:
    r = requests.post(f"{GATEWAY}/api/process",
        headers=HEADERS,
        files={"file": f},
        data={"service_type": "taiwanese_asr"})
print(r.json()["data"]["text"])

# ── 中文語音 → 中文字（Whisper）──
with open("mandarin.wav", "rb") as f:
    r = requests.post(f"{GATEWAY}/api/process",
        headers=HEADERS,
        files={"file": f},
        data={"service_type": "chinese_asr", "language": "zh"})
print(r.json()["data"]["text"])

# ── 中文字 → 台語語音（Gemini + MMS-TTS）──
r = requests.post(f"{GATEWAY}/api/process",
    headers=HEADERS,
    data={
        "service_type": "taiwanese_tts",
        "text_input": "你好，今天天氣真好"
    })
result = r.json()["data"]
print(result["tailo_romanization"])
wav = base64.b64decode(result["audio_base64"])
with open("taiwanese.wav", "wb") as f:
    f.write(wav)

# ── 中文字 → 台灣國語語音（BreezyVoice）──
r = requests.post(f"{GATEWAY}/api/process",
    headers=HEADERS,
    data={
        "service_type": "chinese_tts",
        "text_input": "你好，今天天氣真好"
    })
wav = base64.b64decode(r.json()["data"]["audio_base64"])
with open("mandarin.wav", "wb") as f:
    f.write(wav)
```

## 新增服務

只需兩步，不改程式碼：

**步驟 1：** 在 `services_config.yaml` 加設定

**步驟 2：** 啟動對應微服務

熱重載：`POST /api/reload-config`

## 專案結構

```
├── gateway.py                      # API 網關
├── security.py                     # 安全中間件
├── services_config.yaml            # 服務設定
├── start_all.sh                    # 一鍵啟動
├── deploy.sh                       # VPS 部署腳本
├── manage.sh                       # 日常管理工具
├── docker-compose.yml
└── services/
    ├── breezy_asr/                 # 台語 ASR（Breeze-ASR-26）
    ├── chinese_asr/                # 中文 ASR（Whisper）
    ├── taiwanese_tts/              # 台語 TTS（Gemini + MMS-TTS）
    └── breezy_tts/                 # 中文 TTS（BreezyVoice）
```
